import React from 'react'
import { useForm } from 'react-hook-form';

function AddLeadForm() {
    const {register, handleSubmit} = useForm()
  return (
    <div>
      
    </div>
  )
}

export default AddLeadForm
