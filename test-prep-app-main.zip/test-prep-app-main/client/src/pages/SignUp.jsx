import React from 'react'
import FormInput from '../components/FormInput/FormInput'

function SignUp() {
  return (
    <div>
      <FormInput />
    </div>
  )
}

export default SignUp
